# Uninstall-TeamViewer-Batch
Batch script to run with admin rights, it will uninstall any version of TeamViewer from the machine. DO NOT run this script if you have 2 or more versions currently installed on the machine.
